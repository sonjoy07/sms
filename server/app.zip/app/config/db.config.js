module.exports = {
  HOST: "162.0.214.36",
  USER: "epathshala",
  PASSWORD: "Epathshala@123",
  DB: "epathshala",
};
  