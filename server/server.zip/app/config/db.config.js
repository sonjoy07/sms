module.exports = {
  HOST: "162.0.214.36",
  USER: "epathshala",
  PASSWORD: "Bithi@123",
  DB: "epathshala",
};
  