import React from 'react'
import './AboutUs.css';

const AboutUs = () => {
  return (
    <div class="about-section">
      <div>
      {/* <h1 style={{color: '#006666'}}>About Us</h1> */}
      <h5>Best Web Design and Development Company</h5>
      <p >epthaShala is a Web design and development service providing company in Bangladesh. It has versatile functions. It is the only Best Web Design and Development Company which has all in one. We specialize in Front-End Development, Software and Web Development, Digital Marketing, IoT, Data Science, Machine Learning, and the list goes on.

       The projects we provide are unique and cr very beginning to eative. From thetill now, we have been working in this field with the highest success and client satisfaction. Our team is highly expert and we use digital technology to provide services. We provide the best Web Design and Development full services with an inexpensive range and deliver the projects in time. Our team is responsible, accountable, effective, and efficient. We promote honesty, integrity, and sincerity as well.</p>
      </div>

      {/* <div>
      <h1 style={{color: '#00008B'}}>Our Mission</h1>
      <p >epthaShala is a Bangladesh, UK and Dubai based Best Web Design Company doing highly qualitative development of software, web and mobile apps solution To achieve your goal an array of experienced IT passionate working ,those are really happy to talk , hear and willing to help to reach your goal and implement the strategy-The team Soft IT Care.

       .</p>
      </div>

      <div>
      <h1 style={{color: '#00008B'}}>Our Vision</h1>
      <p >epthaShala is a Web design and development service providing company in Bangladesh. It has versatile functions. It is the only Best Web Design and Development Company which has all in one. We specialize in Software Development, e-Commerce, Graphic Design, Marketing and SEO, Website Security, Mobile Application Development, and the list goes on.

       </p>
      </div> */}
    </div>
  )
}

export default AboutUs