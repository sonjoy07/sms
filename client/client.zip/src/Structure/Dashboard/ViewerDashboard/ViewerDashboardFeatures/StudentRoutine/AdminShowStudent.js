import React from 'react';

const AdminShowStudent = () => {
    return (
        <div>
            add student
        </div>
    );
};

export default AdminShowStudent;